def greetings():
    print("auc")
