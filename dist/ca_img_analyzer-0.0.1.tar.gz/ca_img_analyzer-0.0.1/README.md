# Calcium Imaging Analyzer
`ca_img_analyzer` facilitates the analysis of experimental calcium imaging data.
