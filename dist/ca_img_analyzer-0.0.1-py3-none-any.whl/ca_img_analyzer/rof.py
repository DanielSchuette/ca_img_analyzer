def greetings():
    print("rof")
